var x=0;
var input;
var filter;
var table;
var tr;
var th;
var i;
var txtValue;
function Save(){

 
    var EmployeeName=document.getElementById("EN").value;
    var EmployeeAdress=document.getElementById("EA1").value;
    var EmployeePhoneNumber=document.getElementById("EP").value;
    var EmployeeAge=document.getElementById("EA2").value;
    
    if(EmployeeName==""||EmployeeAdress==""||EmployeePhoneNumber==""||EmployeeAge==""){

        alert('please enter all the information #$%#$#$#% '  );
        
        }
        else{
            x=x+1;
            var table = parent.frame02.document.getElementById("Table1")
            var row =table.insertRow();
            var cell0 = row.insertCell(0);
            var cell1 = row.insertCell(1);
            var cell2 = row.insertCell(2);
            var cell3 = row.insertCell(3);
            var cell4 = row.insertCell(4);

            cell0.innerHTML = x;
            cell1.innerHTML = EmployeeName;
            cell2.innerHTML = EmployeeAdress;
            cell3.innerHTML = EmployeePhoneNumber;
            cell4.innerHTML = EmployeeAge;
            parent.frame03.document.getElementById("EN").disabled=true;
            parent.frame03.document.getElementById("EA1").disabled=true;
            parent.frame03.document.getElementById("EP").disabled=true;
             parent.frame03.document.getElementById("EA2").disabled=true;
                
        }
             
}
function add(){
    parent.frame03.document.getElementById("EN").disabled=false;
    parent.frame03.document.getElementById("EA1").disabled=false;
    parent.frame03.document.getElementById("EP").disabled=false;
    parent.frame03.document.getElementById("EA2").disabled=false;
}

function productUpdate()
{
xy = window.prompt("Input the Row number(0,1,2,3,4)", "0");
yx = window.prompt("Input the Column number(0,1,2,3,4)","0");
content = window.prompt("Input the Cell content");  
var xx=document.getElementById('Table1').rows[parseInt(xy,10)].cells;
xx[parseInt(yx,10)].innerHTML=content;
}

function ID_Search() {
    
    input = document.getElementById("value");
    filter = input.value.toUpperCase();
    table = document.getElementById("Table1");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      th = tr[i].getElementsById("id")[0];
      if (th) {
        txtValue = th.textContent || th.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }       
    }
  }
function Name_search() {
    
    input = document.getElementById("value");
    filter = input.value.toUpperCase();
    table = document.getElementById("Table1");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      th = tr[i].getElementsById("name")[0];
      if (th) {
        txtValue = th.textContent || th.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }       
    }
  }

function Address_Search() {
    
    input = document.getElementById("value");
    filter = input.value.toUpperCase();
    table = document.getElementById("Table1");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
        th = tr[i].getElementsById("Address")[0];
        if (th) {
            txtValue = th.textContent || th.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
}

function Phone_Search() {
    
    input = document.getElementById("value");
    filter = input.value.toUpperCase();
    table = document.getElementById("Table1");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
        th = tr[i].getElementsById("Phone")[0];
        if (th) {
            txtValue = th.textContent || th.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
}

function Age_Search() {
    
    input = document.getElementById("value");
    filter = input.value.toUpperCase();
    table = document.getElementById("Table1");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
        th = tr[i].getElementsById("Age")[0];
        if (th) {
            txtValue = th.textContent || th.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
}



