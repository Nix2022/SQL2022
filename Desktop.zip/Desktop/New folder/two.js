function change(){
  var x = document.getElementById("hh").value ;
  
  if(x=="Eddeh Sands"){
document.getElementById("location").value="Jbeil";
  }
  if(x=="Oceana"){
    document.getElementById("location").value="Damour";
  }
  if(x=="Bamboo Bay"){
    document.getElementById("location").value="Jiyye";
  }

}