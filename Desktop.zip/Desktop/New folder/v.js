function myFunction(){
alert('are you sure you want to delete this ligne');
}

function adding(){
    
    alert ("i will add later");
}