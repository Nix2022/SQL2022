





function submit(){
  

    var name =parent.frame1.document.getElementById("name").value ;
    var pass =parent.frame1.document.getElementById("pass").value
    var cpass =parent.frame1.document.getElementById("cpass").value ;

    var resort =parent.frame02.document.getElementById("hh").value;


    var member1 =parent.frame02.document.getElementById("rad1").checked ;
    var member2 =parent.frame02.document.getElementById("rad2").checked ;
    var member3 =parent.frame02.document.getElementById("rad3").checked ;

    if(member1==true)
    var m= "1 month";
    if(member2==true)
    var m= "3 months";
    if(member3==true)
    var m= "1 year";

    var choice1 =parent.frame02.document.getElementById("chek1").checked;
    var choice2 =parent.frame02.document.getElementById("chek2").checked;
    
   
    if(choice1==true) 
    var ch="Chalet"
    if(choice2==true) 
    var ch="Cabinet"


   if(name==""||pass==""||cpass==""||resort==""||member1==false&&member2==false&&member3==false||choice1==false&&choice2==false){

    alert('please enter all the information');
   }

 else  if(pass!=cpass){
   alert("wrong comfirmation password");
}

 else{


 
parent.frame2.document.getElementById("p").innerHTML="Dear Mr/Mrs "+name+", You have chosen to spend the best "+m+" of your life in one of our most beautiful resorts of Lebanon, "+ch+" .In order to provide you with more details, please login-in to our site using your username: "+name+" and password: "+pass+". Thank you for choosing "+resort+" to spend your vacation"
 } 
}

function cancel(){
    var sure = confirm("are you sure you want to clear all data");
    if(sure){
    
    parent.frame1.document.getElementById("name").value="" ;
    parent.frame1.document.getElementById("pass").value="";
    parent.frame1.document.getElementById("cpass").value="" ;
    parent.frame02.document.getElementById("hh").value="";
    parent.frame02.document.getElementById("rad1").checked=false ;
    parent.frame02.document.getElementById("rad2").checked=false ;
    parent.frame02.document.getElementById("rad3").checked =false;
    parent.frame02.document.getElementById("chek1").checked=false;
    parent.frame02.document.getElementById("chek2").checked=false;
    parent.frame02.document.getElementById("location").value="";


}

else{
 
}
}