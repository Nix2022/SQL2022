<?php
 
class Converter{
 
private $rateValue;
 
//I have base these rates on USD :)
private $rates = [
'USD' => 1.0,
'GBP' => 0.7,
'EUR' => 0.800284,
'YEN' => 109.67,
'CAN' => 1.23,
'PHP' => 51.74,
];
 
public function setConvert($amount, $currency_from){
$this->rateValue = $amount/$this->rates[$currency_from];
}
 
public function getConvert($currency_to){
        return round($this->rates[$currency_to] * $this->rateValue, 2);
}
 
public function getRates(){
return $this->rates;
}
}
 
?>