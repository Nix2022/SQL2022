package com.javawithease.business;

/**
 * This program is used to show the use of 
 * substring(int startIndex, int endIndex)  
 * method to get substrings of a given string.
 * @author javawithease
 */
class TestString{
	String str = "www.javawithease.com";
	
	/**
	 * This method is used to get substrings of a given string.
	 * @author javawithease
	 */
	public void showSubString(){
		System.out.println(str.substring(4,16));
	}
}

public class SubStringExample2 {
	public static void main(String args[]){
		//creating TestString object.
		TestString obj = new TestString();
		//method call
		obj.showSubString();
	}
}
