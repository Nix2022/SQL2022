

function myFunction(){
    var x = document.getElementById("hey").Value;
    


    if(x=="Eddeh Sands"){
        document.getElementById("p3").innerHTML.valueOfp3="jbeil";
    }
    if(x=="Oceana"){
        document.getElementById("p3").Value="Dammour";
    }
    if(x=="BambooBay"){
        document.getElementById("p3").Value="Tyr";
    }

}