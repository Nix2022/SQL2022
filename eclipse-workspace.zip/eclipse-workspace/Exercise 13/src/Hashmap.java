import java.util.*;
class Hashmap
{
	public static void main(String arg[]) 
	{	
	   HashMap<Double, String>
	   hm=new HashMap<Double, String>();
//	   int rn = (int) Math.random();
	
	   
       for(int i=1;i<=10;i++)
       {
    	   double y = (double) Math.random()*1;
    	   hm.put( y , "the key is " +i+" " + "\n");
    	   System.out.println(hm);
    	   
       }
       
       
	   
	}
}