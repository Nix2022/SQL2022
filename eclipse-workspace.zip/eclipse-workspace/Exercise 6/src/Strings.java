import java.util.Scanner;


public class Strings {

	static final int MAX_CHAR = 256;

	static void getOccuringChar(String xx)
	{
		
		
		int count[] = new int[MAX_CHAR];

		int len = xx.length();

		
		for (int i = 0; i < len; i++)
			count[xx.charAt(i)]++;

		
		char ch[] = new char[xx.length()];
		for (int i = 0; i < len; i++) {
			ch[i] = xx.charAt(i);
			int find = 0;
			for (int j = 0; j <= i; j++) {

				
				if (xx.charAt(i) == ch[j])
					find++;
			}

			if (find == 1)
				System.out.println(
					"Number of Occurrence of "
					+ xx.charAt(i)
					+ " is:" + count[xx.charAt(i)]);
		}
	}

	   private static Scanner a;
	public static void main(String[] args)
	{
			a = new Scanner(System.in); 
		    System.out.print("Enter a String \n");
	String xx = a.nextLine();
		getOccuringChar(xx);
	}
}
