import java.util.Scanner;

public class ATM {
	public static void useATM(BankAccount bankAccount) {
        Scanner scanner = new Scanner(System.in);
        char option = '\0';
        do {
            Menu.showMenu();
            option = scanner.next().charAt(0);
           int option1 = scanner.nextInt();
            switch (option) {
                case '1':
                    System.out.println(bankAccount.getBalance());
                    break;
                case '2':
                	System.out.println("Enter amout to withdraw NB($20 , $50 , $100 only allow");
                	int amount1 = scanner.nextInt();
                	if(amount1==20 || amount1==50 || amount1==100) {
                    System.out.println("Enter how Many " + amount1 + "  you want to transfer"); 
                    int count = scanner.nextInt();
                    int amountToWithdraw = amount1*count;
                    bankAccount.withdraw(amountToWithdraw);
                	}
                	else {
                		System.err.println("Wrong Input");
                	}
                    break;
                case '3':
                    System.out.println("Enter an amount Number to Transfer: ");
                    int amountToTransfer = scanner.nextInt();
                    System.out.println("Enter First Account Number: \n");
                    int Account1 = scanner.nextInt();
                    System.out.println("Enter Second Account Number: ");
                    int Account2 = scanner.nextInt();
                   
                    bankAccount.Transfer(amountToTransfer,Account1,Account2 );
                    
                    break;
                case '4':
                	String Account = scanner.nextLine();
                    bankAccount.IsZero(Account,scanner);
                    break;
                case '5':
                	System.out.println("You want to print your transaction(1) or your Withdraw(2)");
                	int Option = scanner.nextInt();
//                	 System.out.println("Dear Client please Enter Your Name : ");
//                     String Name2 = scanner.nextLine();
                     System.out.print(" ");
                     if(option==1) {
                     System.out.println("enter account Number  transfer to ");
                     }
                 	int account2 = scanner.nextInt();
                	
                	bankAccount.Print(Option,account2);
                    break;
                case '0':
                    System.out.println("The transaction is over. ");
                    break;
                default:
                    System.out.println("Not a valid option. Choose another option.");
                    break;
            }
        } while (option != 'X');
    }
}