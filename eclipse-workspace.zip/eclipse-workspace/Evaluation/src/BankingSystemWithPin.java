import java.util.Scanner;

public class BankingSystemWithPin {
    private static int pinAttempts = 0;  
    public static void main(String[] args) {
        BankAccount Account1 = new BankAccount("25750", 200, "1234", "Nicolas Salloum");
        BankAccount Account2 = new BankAccount("25760", 200, "7530","Marcelino Atallah" );
        BankAccount Account3 = new BankAccount("25770", 200, "7531", "Georges Abou Jaoude");
        BankAccount Account4 = new BankAccount("25780", 200, "7532", "Charbel Attallah");
        BankAccount Account5 = new BankAccount("25790", 200, "7533", "Joe Bernard ");
        BankAccount Account6 = new BankAccount("25800", 200, "7534", "Rony Weter");
        BankAccount Account7 = new BankAccount("25761", 200, "7535", "Gebran Hadchity");
        BankAccount Account8 = new BankAccount("25762", 200, "7536", "Charbel Daoud");
        BankAccount Account9 = new BankAccount("25763", 200, "7537", "Marie Belle Salloum");
        BankAccount Account10 = new BankAccount("25764", 2000, "7538", "Abed Banna");
        BankAccount[] bankAccounts = {Account1, Account2, Account3, Account4, Account5, Account6, Account7, Account8, Account9, Account10};
        Scanner scanner = new Scanner(System.in);
        BankAccount currentBankAccount = null;
        while (currentBankAccount == null) {
            pinAttempts++;
            if (pinAttempts > 3) {
                System.err.println();
                System.err.println("You have exceeded the allowable number of login attempts!");
                System.err.println("The transaction is over. ");
                System.exit(0);
            }
//            BankAccount.class.)
            Menu.welcome();
            String pin = scanner.nextLine();
            String Acc = scanner.nextLine();
            String Name = scanner.nextLine();
            currentBankAccount = BankingSystemWithPin.getBankAccountBynumberandpin(bankAccounts, pin, Acc,Name);
        }
        ATM.useATM(currentBankAccount);  
    }
    public static BankAccount getBankAccountBynumberandpin(BankAccount[] bankAccounts, String pin , String Account, String Name) {
        for (BankAccount bankAccount : bankAccounts) {
            if (bankAccount.pin.equals(pin) && bankAccount.Account.equals(Account) ) {
                System.out.println();
                System.out.println("Account Number: " + bankAccount.Account + " Hello Mr." + bankAccount.Name);
                return bankAccount;
            } 
        }
        System.err.println("Wrong Pin. Try Again.");
        System.err.println();
        return null;
    }
   
}