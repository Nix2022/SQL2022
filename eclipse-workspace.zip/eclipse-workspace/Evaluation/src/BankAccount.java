import java.io.FileWriter;
import java.util.Scanner;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class BankAccount {
    String Account;
    int balance;
    String pin;
    String Account1;
    String Account2;
    int amount;
    String Name;
//	private Scanner scanne;
    public BankAccount(String Acc, int balance, String pin, String Name) {
        this.Account = Acc;
        this.balance=balance;
        this.pin = pin;
        this.Account1 = Account1;
        this.Account2=Account2;
        this.amount=this.amount;
        this.Name=Name;
//        this.scanner=this.scanner;
        
    }
	public int getBalance() {
        return this.balance;
    }
  
    public void withdraw(int amount) {
        if (amount <= this.balance) {
            this.balance = this.balance - amount;
            System.out.println("You withdrew " + amount);
        } else {
            System.out.println("Not enough money. ");
        }
    }
    public void Transfer(int amount, int account1 , int account2) {
        if (amount <= this.balance) {
            this.balance = this.balance - amount;
            System.out.println("I transfer the amount of" +amount+" from the account number "+ account1 +"to the account number "+ account2 +" and remaining balance is"+balance);
        } else {
            System.out.println("Not enough money. ");
        }
    }
    public void IsZero(String Account,Scanner scanner) {
    if (this.balance>0) {   
        System.out.println("you have money don't worry");}
     else if(this.balance==0){
        System.out.println("Do you want to delete your account? yes Press (1) no Press (2)");
        int Option1 = scanner.nextInt();
        if(Option1==1 ) {
        	System.err.println("Go to the nearest Branch");
        }
        else if(Option1==2){
        	System.err.println("Good Bye");
        }
    }
   
}
    public void Print(int Option,int account2) {	
    	int Withdraw= 200-this.balance;
    	int amount = 200-this.balance;
    	DateTimeFormatter date = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
    	   LocalDateTime now = LocalDateTime.now();  
    if (Option==1) {
        System.out.println("a transaction was made with the amount of $" + amount + "to the account number " + account2 );
        try {
            FileWriter myWriter = new FileWriter("C:\\Users\\nicolas.s\\Desktop\\Nicolas.txt");
            myWriter.write("a transaction was made with the amount of $" + amount + "to the account number " + account2 + " " + date.format(now) );
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
          } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
          }
    }	else if(Option==2) {
    	System.out.println("you withrew  $" + Withdraw  );
    	  try {
              FileWriter myWriter = new FileWriter("C:\\Users\\nicolas.s\\Desktop\\Nicolas.txt");
              myWriter.write("you withrew $" + Withdraw + " from your account  " + date.format(now) );
              myWriter.close();
              System.out.println("Successfully wrote to the file.");
            } catch (IOException e) {
              System.out.println("An error occurred.");
              e.printStackTrace();
            }
    }
    else {
        System.out.println("error");
    }
}
//    public void static delete(int Account)
//    {
//    	
//    	
//    }
}