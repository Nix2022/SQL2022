public class Menu {
    public static void showMenu() {
        System.out.println("Enter an option: ");
        System.out.println("1. Check balance ");
        System.out.println("2. Withdraw ");
        System.out.println("3. Transfer ");
        System.out.println("4. Check if balance is 0 ");
        System.out.println("5.Print all  in information  " );
        System.out.println("0. Exit");
    }
        public static void welcome() {
        System.out.println("Welcome! To Valoores's Bank");
        System.out.println("Please insert your pin & your account number: ");
    }
}