import java.util.HashMap;

import java.util.Scanner;

public class Car {

	
	
	
	static int plate_Number = (int) (Math.random()*100000);
	public static void main(String arg[]) 
	{
		
	Scanner sc = new Scanner(System.in);
	System.out.println("If you want to finish Say Finish");
	
//	int tableSize = 0;
//	printinfoTable(tableSize);
	 
	int tableSize = 0;
for( String Finish = sc.nextLine(); Finish.equalsIgnoreCase("Finish");) {
		HashMap<Integer, String>
		   carinf=new HashMap<Integer, String>();
		HashMap<Integer, Integer>
			carinf1 = new HashMap<Integer, Integer>(); 
		sc.close();
	System.out.println("enter the car Brand");
	String Brand = sc.nextLine();
	
	System.out.println("enter the car Model");
	int Model = sc.nextInt();
	
	System.out.println("enter the Number of passengers ");
	int Passenger = sc.nextInt();
	
	carinf.put(plate_Number,Brand);
	carinf1.put(Model, Passenger);
	
	HashMap<Object, Object> carinfall = new HashMap<>();
	carinfall.putAll(carinf1);
	carinfall.putAll(carinf);

	
     
     System.out.format("      ");
    
	for(int i = 1; i<=tableSize;i++ ) {
         System.out.format("%4s",i);
     }
     System.out.println();
     System.out.println("------------------------------------------");
     System.out.println("Plate Number"+"|"+"Car Brand"+"|"+"Car Model"+"|"+"N0. Of Passengers");
//     System.out.println("   "+ plate_Number+" 	"+Brand+" 	"+Model+"		 "+Passenger);
      
     for(int i = 1 ;i<=tableSize;i++) {
    
         System.out.format("%4s |",i);
         for(int j=1;j<=tableSize;j++) {
             System.out.format("%4s","   "+ plate_Number+" 	"+Brand+" 	"+Model+"		 "+Passenger);
         }
         System.out.println();
     }
     System.out.println(carinfall);
     tableSize++;
 
	
//System.out.println("Good Bye");
}
	}
 

//	 public static void printinfoTable(int tableSize) {
//		 HashMap<Object, Object> carinfall = new HashMap<>();
//	        
//	        System.out.format("      ");
//	        for(int i = 1; i<=tableSize;i++ ) {
//	            System.out.format("%4d",i);
//	        }
//	        System.out.println();
//	        System.out.println("------------------------------------------");
//	         
//	        for(int i = 1 ;i<=tableSize;i++) {
//	       
//	            System.out.format("%4d |",i);
//	            for(int j=1;j<=tableSize;j++) {
//	                System.out.format("%4d",carinfall);
//	            }
//	            System.out.println();
//	        }
//	    }
	
}

	
	

