import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;


class Employee implements Serializable
{

	int ID1;
	String Name;
//	String Lname;
	int Age;
	int Personal_File;
	
	public Employee(int ID1,String Name,int Age,int Personal_File)
	{
		this.Name=Name;
//		this.Lname=Lname;
		this.Age=Age;
		this.Personal_File=Personal_File;
		this.ID1=ID1;
	}
	public String toStringEmp()
	{
		return "\nEmployee Details :" +"\nID:" + this.ID1 + "\nFname: " + this.Name  + "\nAge: " + 
				this.Age + "\nPersonal File ID: " + this.Personal_File  ;
	}
}
@SuppressWarnings("serial")
class Address implements Serializable
{
	String Street;
	String City;
	String Building;
	int Floor ;
	
	
	public Address(String Street,String City,String Building,int Floor )
	{
		this.Street=Street;
		this.City=City;
		this.Building=Building;
		this.Floor=Floor;
	}
	public String toStringAdd()
	{
		return "\nAddress Details :" + "\nstreet: " + this.Street + "\nCity: " + this.City + "\nBuilding: " + 
				this.Building + "\nFloor: " + this.Floor  ;
	}
	
}
@SuppressWarnings("serial")
class Department implements Serializable
{
	String Description;
	String List_Of_Employee;
	int Floor1;
	public Department(String Description,String List_Of_Employee,int Floor1)
	{
		
		this.Description=Description;
		this.List_Of_Employee=List_Of_Employee;
		this.Floor1=Floor1;
	}
	public String toStringDep()
	{
		return "\nDepartment Details :" + "\nDescription: " + this.Description + "\nFloor: " + this.Floor1 + "\nList Of Employee: " + 
				this.List_Of_Employee   ;
	}
	
}
@SuppressWarnings("serial")
class Personal_File implements Serializable
{
	String Profession;
	String Experience;
	int IQ_test;
	int ID2;
	public Personal_File(int ID2,String Profession, String Experience, int IQ_test)
	{
		this.Profession=Profession;
		this.Experience=Experience;
		this.IQ_test=IQ_test;
		this.ID2=ID2;
	}
	public String toStringPer()
	{
		return "\nPersonal_FIle Details :" +"\nID: " + this.ID2+ "\nProfession: " + this.Profession + "\nExperince: " + this.Experience + "\nIQ: " + 
				this.IQ_test   ;
	}
	
}
@SuppressWarnings("serial")
class Management implements Serializable
{
	int Working_Hours;
	String Working_Days;
	String Vacations;
	public Management(int Working_hours, String Working_Days,String Vacations)
	{
		this.Working_Hours=Working_hours;
		this.Working_Days=Working_Days;
		this.Vacations=Vacations;
	}
	public String toStringMan()
	{
		return "\nManagement Details :" + "\nWorking Hours: " + this.Working_Hours + "\nWorking Days: " + this.Working_Days +  "\nVacation Days: " + this.Vacations  ;
	}
}



public class Company_Management {
	static void displayemp(ArrayList<Employee> emp)
	{
		System.out.println("\n--------------Employee Details---------------\n");
		System.out.println(String.format("%-10s-%-10s%-15s%-10s%-20s","ID", "First Name","Last Name","Age","Personal File"));
		for(Employee e : emp)
		{
			System.out.println(String.format("%-5s%-5s%-20s%-10s%-15s",e.ID1,e.Name,e.Age,e.Personal_File));
		}
	}
	static void displayadd(ArrayList<Address> Add)
	{
		System.out.println("\n--------------Address Details---------------\n");
		System.out.println(String.format("%-10s%-15s%-10s%-20s", "Street","City","Building","Floor"));
		for(Address e : Add)
		{
			System.out.println(String.format("%-5s%-20s%-10s%-15s",e.Street,e.City,e.Building,e.Floor));
		}
	}
	static void displayDep(ArrayList<Department> Dep)
	{
		System.out.println("\n--------------Department Details---------------\n");
		System.out.println(String.format("%-10s%-15s%-10s", "Description","Floor","List Of Employee"));
		for(Department e : Dep)
		{
			System.out.println(String.format("%-5s%-20s%-10s",e.Description,e.Floor1,e.List_Of_Employee));
		}
	}
	
	static void displayPer(ArrayList<Personal_File> PF)
	{
		System.out.println("\n--------------Personal File Details---------------\n");
		System.out.println(String.format("%-10s%-10s%-15s%-10s", "ID","Profession","Experience","IQ Test Grade"));
		for(Personal_File e : PF)
		{
			System.out.println(String.format("%-5s%-5s%-20s%-10s",e.ID2,e.Profession,e.Experience,e.IQ_test));
		}
	}
	static void displayMan(ArrayList<Management> Man)
	{
		System.out.println("\n--------------Management Details---------------\n");
		System.out.println(String.format("%-10s%-15s%-10s", "Working Hours","Working Days","Vacations"));
		for(Management e : Man)
		{
			System.out.println(String.format("%-5s%-20s%-10s",e.Working_Hours,e.Working_Days,e.Vacations));
		}
	}
	

	public static void main(String[] args)
	{
//		String Fname;
//		String Lname;
		String Name;
		int Age;
		int Personal_File;
		String Street;
		String City;
		String Building;
		int Floor ;
		String Description;
		String List_Of_Employee;
		int Floor1;
		String Profession;
		String Experience;
		int IQ_test;
		int Working_Hours;
		String Working_Days;
		String Vacations;
		int ID1;
		int ID2;
		
		Scanner sc = new Scanner(System.in);
		ArrayList<Employee> emp = new ArrayList<Employee>();
		Scanner sc1 = new Scanner(System.in);
		ArrayList<Address> Add = new ArrayList<Address>();
		Scanner sc2 = new Scanner(System.in);
		ArrayList<Department> Dep = new ArrayList<Department>();
		Scanner sc3 = new Scanner(System.in);
		ArrayList<Personal_File> PF = new ArrayList<Personal_File>();
		Scanner sc4 = new Scanner(System.in);
		ArrayList<Management> Man = new ArrayList<Management>();
		
		File f = null;
		FileInputStream fis = null;
		ObjectInputStream ois = null;
		FileOutputStream fos = null;
		ObjectOutputStream oos =null;
		sc.close();
		sc1.close();
		sc2.close();
		sc3.close();
		sc4.close();
try{
			
			f = new File("Info.txt");
			if(f.exists())
			{
				fis = new FileInputStream(f);
				ois = new ObjectInputStream(fis);
				emp = (ArrayList<Employee>)ois.readObject();
				Add = (ArrayList<Address>)ois.readObject();
				Dep = (ArrayList<Department>)ois.readObject();
				PF = (ArrayList<Personal_File>)ois.readObject();
				Man = (ArrayList<Management>)ois.readObject();
			}
			
		}
		catch(Exception exp){
			System.out.println(exp);
		}
		do
			{
	System.out.println("\n*********Welcome to the Company Management System**********\n");
	System.out.println("11). Add Address\n" +"12). Add Department\n" +"13). Add Employee\n" +"14). Add Personal File\n" +"15). Add management\n" +
						"21). Search for Address\n" +"22). Search for Department\n" +"23). Search for Employee\n" +"24). Search for Personal File\n" +"25). Search for Management\n" +
						"31). Edit Address details\n" +"32). Edit Department details\n" +"33). Edit Employee details\n" +"34). Edit Personal File details\n" +"35). Edit Management details\n" +
						"41). Delete Address Details\n" +"42). Delete Department Details\n" +"43). Delete Employee Details\n" +"44). Delete Personal File Details\n"  +
						"51). Display Addresses for this company\n" +"52). Display all Departments for this company\n" +"53). Display all Employees working in this company\n" +"54). Display all Personal FIles in this company\n"  +
						"6). EXIT\n");
	System.out.println("Enter your choice : ");
	int ch = sc.nextInt();
		switch(ch)
		{
		case 11:System.out.println("\nEnter the following details to ADD list:\n");
		System.out.println("Enter Street :");
		Street = sc1.nextLine();
		System.out.println("Enter City :");
		City = sc1.nextLine();
		System.out.println("Enter Building :");
		Building = sc1.nextLine();
		System.out.println("Enter Floor :");
		Floor = sc1.nextInt();
		Add.add(new Address(Street, City, Building, Floor));
		displayadd(Add);
		break;
		
		case 12:System.out.println("\nEnter the following details to ADD list:\n");
		System.out.println("Department Description :");
		Description = sc2.nextLine();
		System.out.println("Department Floor :");
		Floor1 = sc2.nextInt();
		System.out.println("List of Employee :");
		List_Of_Employee = sc2.nextLine();
		Dep.add(new Department(Description, List_Of_Employee, Floor1));
		displayDep(Dep);
		break;
		
		case 13:System.out.println("\nEnter the following details to ADD list:\n");
		System.out.println("Employee ID :");
		ID1 = sc.nextInt();
		System.out.println("Employee Name :");
		Name = sc.nextLine();
//		System.out.println("Employee Last Name :");
//		Lname = sc.nextLine();
		System.out.println("Employee Age :");
		Age = sc.nextInt();
		System.out.println("Employee Personal File ID");
		ID2=sc.nextInt();
		emp.add(new Employee(ID1,Name,Age,ID2));
		displayemp(emp);
		break;
		
		case 14:System.out.println("\nEnter the following details to ADD list:\n");
		System.out.println("Employee ID :");
		ID2 = sc3.nextInt();
		System.out.println("Employee Professions :");
		Profession = sc3.nextLine();
		System.out.println("Experience Period :");
		Experience = sc3.nextLine();
		System.out.println("IQ Test Grade :");
		IQ_test = sc3.nextInt();
		PF.add(new Personal_File(ID2, Profession,Experience,IQ_test));
		displayPer(PF);
		break;
		
		case 15:System.out.println("\nEnter the following details to ADD list:\n");
		System.out.println("Working Hours :");
		Working_Hours =sc4.nextInt();
		System.out.println("Working Days :");
		Working_Days = sc4.nextLine();
		System.out.println("Vacations :");
		Vacations = sc4.nextLine();
		Man.add(new Management(Working_Hours,Working_Days, Vacations));
		displayMan(Man);
		break;
		
		case 23: System.out.println("Enter the Employee ID to search :");
		ID1 = sc.nextInt();
		int i=0;
		for(Employee e: emp)
		{
			if(ID1 == e.ID1)
			{
				System.out.println(e+"\n");
				i++;
			}
		}
		if(i == 0)
		{
			System.out.println("\nEmployee Details are not available, Please enter a valid ID!!");
		}
		break;
		
		case 21: System.out.println("Enter the Address Street to search :");
		Street = sc.nextLine();
		int i1=0;
		for(Address e: Add)
		{
			if(Street == e.Street)
			{
				System.out.println(e+"\n");
				i1++;
			}
		}
		if(i1 == 0)
		{
			System.out.println("\nAddress Details are not available, Please enter a valid City!!");
		}
		break;
		
		case 22: System.out.println("Enter the Department Floor to search :");
		Floor1 = sc.nextInt();
		int i2=0;
		for(Department e: Dep)
		{
			if(Floor1 == e.Floor1)
			{
				System.out.println(e+"\n");
				i2++;
			}
		}
		if(i2 == 0)
		{
			System.out.println("\nDepartment Details are not available, Please enter a valid Department Floor!!");
		}
		break;
		
		case 24: System.out.println("Enter the Personal File ID to search :");
		ID2 = sc.nextInt();
		int i3=0;
		for(Personal_File e: PF)
		{
			if(ID2 == e.ID2)
			{
				System.out.println(e+"\n");
				i3++;
			}
		}
		if(i3 == 0)
		{
			System.out.println("\nPersonal File Details are not available, Please enter a valid File ID!!");
		}
		break;
		
		case 33: System.out.println("\nEnter the Employee ID to EDIT the details");
		ID1 = sc.nextInt();
		int j=0;
		for(Employee e: emp)
		{
			if(ID1 == e.ID1)
			{	
				j++;
			do{
				int ch1 =0;
				System.out.println("\nEDIT Employee Details :\n" +
									"1). Employee ID\n" +
									"2). Name\n" +
								
									"3). Age\n" +
									"4). Personal File ID\n" +
									"5). GO BACK\n");
				System.out.println("Enter your choice : ");
				ch1 = sc.nextInt();
				switch(ch1)
				{
				case 1: System.out.println("\nEnter new Employee ID:");
						e.ID1 =sc.nextInt();
						System.out.println(e+"\n");
						break;
				
				case 2: System.out.println("Enter new Employee First Name:");
						e.Name =sc.nextLine();
						System.out.println(e+"\n");
						break;
						
				
						
				case 3: System.out.println("Enter new Employee Age :");
						e.Age =sc.nextInt();
						System.out.println(e+"\n");
						break;
						
				case 4: System.out.println("Enter new Employee Personal File :");
						e.Personal_File =sc.nextInt();
						System.out.println(e+"\n");
						break;
						
				case 5: j++;
						break;
						
				default : System.out.println("\nEnter a correct choice from the List :");
							break;
				
				}
				}
			while(j==1);
			}
		}
		if(j == 0)
		{
			System.out.println("\nEmployee Details are not available, Please enter a valid ID!!");
		}
	
		break;
		case 31: System.out.println("\nEnter the Address Street to EDIT the details");
		Street = sc.nextLine();
		int j1=0;
		for(Address e: Add)
		{
			if(Street == e.Street)
			{	
				j1++;
			do{
				int ch1 =0;
				System.out.println("\nEDIT Address Details :\n" +
									"1). Street\n" +
									"2). City\n" +
									"3). Building\n" +
									"4). Floor\n" +
									
									"5). GO BACK\n");
				System.out.println("Enter your choice : ");
				ch1 = sc.nextInt();
				switch(ch1)
				{
				case 1: System.out.println("\nEnter new Address Street:");
						e.Street =sc.nextLine();
						System.out.println(e+"\n");
						break;
				
				case 2: System.out.println("Enter new Address City:");
						e.City =sc.nextLine();
						System.out.println(e+"\n");
						break;
						
				case 3: System.out.println("Enter new Address Building:");
						e.Building =sc.nextLine();
						System.out.println(e+"\n");
						break;
						
				case 4: System.out.println("Enter new Address Floor :");
						e.Floor =sc.nextInt();
						System.out.println(e+"\n");
						break;
						
				case 5: j1++;
						break;
						
				default : System.out.println("\nEnter a correct choice from the List :");
							break;
				
				}
				}
			while(j1==1);
			}
		}
		if(j1 == 0)
		{
			System.out.println("\nAddress Details are not available, Please enter a valid Address!!");
		}
	
		break;
		
		case 32: System.out.println("\nEnter the Department Floor to EDIT the details");
		Floor1 = sc.nextInt();
		int j2=0;
		for(Department e: Dep)
		{
			if(Floor1 == e.Floor1)
			{	
				j2++;
			do{
				int ch1 =0;
				System.out.println("\nEDIT Department Details :\n" +
									"1). Description\n" +
									"2). Floor\n" +
									"3). List_Of_Employee\n" +
									"4). GO BACK\n");
				System.out.println("Enter your choice : ");
				ch1 = sc.nextInt();
				switch(ch1)
				{
				case 1: System.out.println("\nEnter new Department Description:");
						e.Description =sc.nextLine();
						System.out.println(e+"\n");
						break;
				
				case 2: System.out.println("Enter new Department Floor:");
						e.Floor1 =sc.nextInt();
						System.out.println(e+"\n");
						break;
						
				case 3: System.out.println("Enter new Department List of Employee:");
						e.List_Of_Employee =sc.nextLine();
						System.out.println(e+"\n");
						break;
						
				
				case 4: j2++;
						break;
						
				default : System.out.println("\nEnter a correct choice from the List :");
							break;
				
				}
				}
			while(j2==1);
			}
		}
		if(j2 == 0)
		{
			System.out.println("\nDepartment Details are not available, Please enter a valid Floor!!");
		}
	
		break;
		
		case 34: System.out.println("\nEnter the Personal File ID to EDIT the details");
		ID2 = sc.nextInt();
		int j3=0;
		for(Personal_File e: PF)
		{
			if(ID2 == e.ID2)
			{	
				j3++;
			do{
				int ch1 =0;
				System.out.println("\nEDIT Personal File Details :\n" +
									"1). File ID\n" +
									"2). Profession\n" +
									"3). Experieice \n" +
									"4). IQ Test Grade\n" +
									"5). GO BACK\n");
				System.out.println("Enter your choice : ");
				ch1 = sc.nextInt();
				switch(ch1)
				{
				case 1: System.out.println("\nEnter new File ID:");
						e.ID2 =sc.nextInt();
						System.out.println(e+"\n");
						break;
				
				case 2: System.out.println("Enter new File Profession:");
						e.Profession =sc.nextLine();
						System.out.println(e+"\n");
						break;
						
				case 3: System.out.println("Enter new File Experience:");
						e.Experience =sc.nextLine();
						System.out.println(e+"\n");
						break;
						
				case 4: System.out.println("Enter new IQ Test Grade :");
						e.IQ_test =sc.nextInt();
						System.out.println(e+"\n");
						break;
			
						
				case 5: j3++;
						break;
						
				default : System.out.println("\nEnter a correct choice from the List :");
							break;
				
				}
				}
			while(j3==1);
			}
		}
		if(j3 == 0)
		{
			System.out.println("\nFile Details are not available, Please enter a valid ID!!");
		}
	
		break;
		
		case 43: System.out.println("\nEnter Employee ID to DELETE from the Databse :");
		ID1 = sc.nextInt();
		int k=0;
		try{
		for(Employee e: emp)
		{
			if(ID1 == e.ID1)
			{
					emp.remove(e);
					displayemp(emp);
					k++;
			}
		}
		if(k == 0)
		{
			System.out.println("\nEmployee Details are not available, Please enter a valid ID!!");
		}
		}
		catch(Exception ex){
			System.out.println(ex);
		}
		break;
		
		
		case 41: System.out.println("\nEnter Address Street to DELETE from the Databse :");
		Street = sc.nextLine();
		int k1=0;
		try{
		for(Address e: Add)
		{
			if(Street == e.Street)
			{
					Add.remove(e);
					displayadd(Add);
					k1++;
			}
		}
		if(k1 == 0)
		{
			System.out.println("\nAddress Details are not available, Please enter a valid Street!!");
		}
		}
		catch(Exception ex){
			System.out.println(ex);
		}
		break;
		
		case 42: System.out.println("\nEnter Department Floor to DELETE from the Databse :");
		Floor1 = sc.nextInt();
		int k2=0;
		try{
		for(Department e: Dep)
		{
			if(Floor1 == e.Floor1)
			{
					Dep.remove(e);
					displayDep(Dep);
					k2++;
			}
		}
		if(k2 == 0)
		{
			System.out.println("\nDepartment Details are not available, Please enter a valid Floor!!");
		}
		}
		catch(Exception ex){
			System.out.println(ex);
		}
		break;
		
		
		case 44: System.out.println("\nEnter File ID to DELETE from the Databse :");
		ID2 = sc.nextInt();
		int k3=0;
		try{
		for(Personal_File e: PF)
		{
			if(ID2 == e.ID2)
			{
					PF.remove(e);
					displayPer(PF);
					k3++;
			}
		}
		if(k3 == 0)
		{
			System.out.println("\nFile Details are not available, Please enter a valid ID!!");
		}
		}
		catch(Exception ex){
			System.out.println(ex);
		}
		break;
		
		case 51: try {
			Add = (ArrayList<Address>)ois.readObject();
		
		} catch (ClassNotFoundException e2) {
			
			System.out.println(e2);
		} catch (Exception e2) {
			
			System.out.println(e2);
		}
			displayadd(Add);
			break;
			
		case 52: try {
			Dep = (ArrayList<Department>)ois.readObject();
		
		} catch (ClassNotFoundException e2) {
			
			System.out.println(e2);
		} catch (Exception e2) {
			
			System.out.println(e2);
		}
			displayDep(Dep);
			break;
			
		case 53: try {
			emp = (ArrayList<Employee>)ois.readObject();
		
		} catch (ClassNotFoundException e2) {
			
			System.out.println(e2);
		} catch (Exception e2) {
			
			System.out.println(e2);
		}
			displayemp(emp);
			break;
			
		case 54: try {
			PF = (ArrayList<Personal_File>)ois.readObject();
		
		} catch (ClassNotFoundException e2) {
			
			System.out.println(e2);
		} catch (Exception e2) {
			
			System.out.println(e2);
		}
			displayPer(PF);
			break;
			
			
		case 6: try {
			fos = new FileOutputStream(f);
			oos = new ObjectOutputStream(fos);
			oos.writeObject(emp);
			oos.writeObject(Add);
			oos.writeObject(Dep);
			oos.writeObject(PF);
			oos.writeObject(Man);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		catch(Exception e2){
			e2.printStackTrace();
		}
		finally{
			try {
				fis.close();
				ois.close();
				fos.close();
				oos.close();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			
		}
			System.out.println("\nYou have chosen EXIT !! Saving Files and closing the tool.");
			sc.close();
			System.exit(0);
			break;
			
	default : System.out.println("\nEnter a correct choice from the List :");
				break;
	
	}

		
		}

		while(true);

}
}