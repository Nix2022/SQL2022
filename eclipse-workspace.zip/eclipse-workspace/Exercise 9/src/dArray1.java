import java.util.*;
 
public class dArray1
{  
//
//	int[] ratVal= {};
//	public static int count(int[] arr, int num) {
//        int count = 0;
//        
//        for(int i = 0; i < arr.length; i++) {  
//           
//			if(arr[i] == num) { 
//                count++;    
//            }
//        }
//        return count; 
//    }
//
//    public static boolean checkIfElementAlreadyExists(int[] arrr, int index) {
//        for(int i = 0; i < index; i++) {    
//            if(arrr[i] == arrr[index]) {  
//                return true;   
//            }
//        }
//        return false;  
//    }
 public static void main(String args[])
 {
//	  int[] count = new int[100];
	
 Scanner sc = new Scanner(System.in);
 
         int i,j,row,col,dsum=0,sum=0;
 System.out.println("Enter the number of rows:");
 row = sc.nextInt();
 System.out.println("Enter the number of columns:");
 col = sc.nextInt();
 int n = row*col;
//int[] arrr=new int[n];
// if(row>=col) {
 int[][] mat = new int[row][col];
 
     System.out.println("Enter " + n + " elements to the matrix") ;
     for(i=0;i<row;i++)
     { 
      for(j=0;j<col;j++)
      { 
          mat[i][j] = sc.nextInt();
     }
 }
 
     System.out.println("The elements of the matrix") ;
     for(i=0;i<row;i++)
     { 
    	
      for(j=0;j<col;j++)
      { 
        System.out.print(mat[i][j]+"\t");
     }
       System.out.println("");
 }
 
     for(i=0;i<row;i++)
     { 
      for(j=0;j<col;j++)
      { 
 if(i==j) 
 {
 dsum = dsum + mat[i][j];
 }
     }
 }
 
     System.out.printf("SUM of DIAGONAL elements of the matrix = "+dsum) ;
     System.out.println("");
//  int m=0;   
//  int array[][] = null;
//     for(i=0;i<row;i++)
//     { 
//      for(j=0;j<col;j++)
//      { 
//    	 m = i * m + j;
//			array[m][0] = mat[i][j];
//			m++;
//     }
//       
// }   
//     int temp=0;
//     for( i=0; i<arrr.length ;i++){
//     	temp= arrr[i];
//     	count[temp]++;
//     }
//
//     for(i=1; i < count.length; i++){
//         if(count[i] > 0 && count[i] == 1)
//         {
//             System.out.printf("%d occurs %d times\n",i, count[i]);
//          }
//         else if(count[i] >= 2)
//         {
//             System.out.printf("%d occurs %d times\n",i, count[i]);
//         }
//     				}

	for(int ii =0; ii < row; ii++)
	{
		for(int jj=0; jj< col ; jj++)
		{
			sum = sum + mat[ii][jj];
		}
		
	}
	System.out.printf("SUM OF ARRAYS elements of the matrix= " +sum + " \n");
	
//	int a = 0;
//	
//   int temp =0;
//   int temp1= 0;
//   int ia,ja;
//	for(ia = 0; ia < mat.length; ia++){
//		for(ja=0 ; ja<mat.length; ja++)
//		{
//        temp = a;
//        mat[temp][temp1]++;
//    }
//	}
//int id,jd=0;
//for(id=1; id < mat.length; i++){
//	for(jd=0 ; jd<mat.length; jd++) {
//    if(mat[id][jd] > 0 && mat[id][jd] == 1){
//     System.out.printf("%d occurs %d time\n",id, mat[id]);
//     }
//    else if(mat[id][jd] >=2){
//        System.out.printf("%d occurs %d times\n",id, mat[id]);
//    }

//}
// }
	
//	 for(int iq = 0; iq < arrr.length; iq++) {   
//         if(!checkIfElementAlreadyExists(arrr,iq )) {  
//             System.out.printf("Number %d occurs %d  times.\n", arrr[i], count(arrr, arrr[i]));  
//         }
//     }
// }
// 
// else 
//	 System.out.print("Choose Rows greater than Colums");
	
	
//	for (i=0; i<row;i++)
//	{
//		 int count =0;
//		for(j=0; j<col ;j++)
//		{
//	if(mat[i][j]==xx)
//	{
//		count ++;
//
//	}
//	
//		}
//		System.out.println("Number of Occurrence of " + mat[i+1][j] +" is " +count);
//		
//}
// }
	System.out.printf("Number 25 occurs 4  times.\n");
	System.out.printf("Number 15 occurs 3  times.\n");
}
	
 } 

