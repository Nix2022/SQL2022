import java.util.Scanner;
import java.util.Arrays;

public class MaxadnMin {
		
		
	public static void main(String args[]) 
    { 
	 Scanner sc = new Scanner(System.in);
		sc.close();
	
     int i,size;
System.out.println("Enter the Arrays Size");
size = sc.nextInt();
int[] arr = new int[size];
int[] arr1 = new int[size];
System.out.println("Enter the number of 1st Array");

for(i=0;i<size;i++)
{ 
	arr[i] = sc.nextInt();
}



System.out.println("Enter the number of 2nd Array");
for(i=0;i<size;i++)
{ 
	arr1[i] = sc.nextInt();
}


Arrays.sort(arr);
Arrays.sort(arr1);
int maxNum1 = arr[0];
int Minimum1 = arr[0];

int maxNum2 = arr1[0];
int Minimum2 = arr1[0];

for (int j : arr) {
    if (j > maxNum1)
        maxNum1 = j;
}
for (int j : arr) {
    if (j < Minimum1)
        Minimum1 = j;
}
for (int j : arr1) {
    if (j > maxNum2)
        maxNum2 = j;
}
for (int j : arr1) {
    if (j < Minimum1)
    	Minimum1= j;
}


	
System.out.println("Maximum number of first Array is  = " + maxNum1);
System.out.println("Minimum number of first Array is  = " + Minimum1);
System.out.println("Maximum number of second Array is  = " + maxNum2);
System.out.println("Minimum number of second Array is  = " + Minimum2);
if(maxNum1>maxNum2)
System.out.println("Maximum number of All Arrays is " + maxNum1);
else 
System.out.println("Maximum number of All Arrays is " + maxNum2);
if(Minimum1>Minimum2)
	System.out.println("Minimum number of All Arrays is " + Minimum2);
	else 
System.out.println("Minimum number of All Arrays is " + Minimum1);

    }
	}




	  

