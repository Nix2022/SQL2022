class Exercise100 {
  public static void main(String[] args) {


    for (int i = 1; i <= 100; ++i) {
 
     
      if (i%5==0 && i%2!=0 || i%6==0 || i==51 || i==52 || i==53 || i==54 || i==59 || i==56 || i==57 || i==58 ) {
        continue;
      }
      System.out.println(i);
    }
  }
}