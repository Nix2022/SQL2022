import java.util.Scanner;
public class Test {
	  private static Scanner ab;
   public static void main(String args[]) {
	   ab = new Scanner(System.in); 
	    System.out.print("Enter a text \n");
String xx = ab.nextLine();
      System.out.print("Return Value :" );
      System.out.println(xx.replaceAll(" ", ""));
   }
}