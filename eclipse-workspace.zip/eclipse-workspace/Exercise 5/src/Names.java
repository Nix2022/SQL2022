import java.util.Scanner;
public class Names {

   private static Scanner firstName;
   private static Scanner lastname;
   

public static void main(String args[]) {
	
      
	   firstName = new Scanner(System.in); 
	    System.out.print("Enter your first name.\n");
	    
	    
	 lastname = new Scanner(System.in); 
	    System.out.print("Enter your Last name \n" );
	    
	    String x = firstName.nextLine();
	    String y = lastname.nextLine();
      System.out.print("Return Value : \n");
      System.out.println(x.substring(2,3) );
      System.out.print("Return Value : \n" );
      System.out.println(y.substring(2,3) );
      
String zy = x+y;
      int upper = 0, lower = 0 ;

      for(int i = 0; i < zy.length(); i++)
      {
          char ch = zy.charAt(i);
          if (ch >= 'A' && ch <= 'Z')
              upper++;
          else if (ch >= 'a' && ch <= 'z')
              lower++;
         
      }

      System.out.println("Lower case letters : " + lower);
      System.out.println("Upper case letters : " + upper);
      
 

   }
}