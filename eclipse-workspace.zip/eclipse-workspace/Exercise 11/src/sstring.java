import java.util.Scanner;

public class sstring { 
    public static void main(String args[]) 
    { 
    	
    	@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
    	 System.out.println("Enter your Text");
    	String  str = sc.nextLine();
       int i=0;
    	
        
        String[] arr = str.split(" "); 
  
        for (String s : arr) {
            System.out.println(s); 
        }
       
        System.out.println("The elements of the matrix") ;
        for(i=0;i<arr.length;i++)
        { 
         
           System.out.print(arr[i]+"\t");
        }
    } 
}	
