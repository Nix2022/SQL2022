import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;

public class ReadFile {  
  public static void main(String[] args) {  
	 
    try {
      File myObj = new File("file.txt");
      Scanner myReader = new Scanner(myObj);
      String data = "";
   
      while (myReader.hasNextLine()) {
    	  HashMap<String, String>
   	   Read=new HashMap<String, String>();
         data = myReader.nextLine();
         
    String Data1 = data.replace(" ","");
		String firstThreeChars = Data1.substring(0,3);
        Read.put(firstThreeChars, data);
        System.out.println(Read);
      }
      
     
    } catch (FileNotFoundException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    } 
  }  
} 