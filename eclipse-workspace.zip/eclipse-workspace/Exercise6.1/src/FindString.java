import java.util.Scanner;

public class FindString {
	  private static Scanner a;
	  private static Scanner Find;
	public static void main(String args[]) {
		 
			
					a = new Scanner(System.in); 
				    System.out.print("Enter a Text \n");
			String xx = a.nextLine();
				
			
		
		 Find  = new Scanner(System.in);
		 System.out.print("Enter the world you need to search  ");
		 String yy = Find.nextLine();
		 
		 int fix = xx.indexOf(yy);
		System.out.println(" the world is at the idex " + fix + " ");
	
}}