package test1;
import java.util.Scanner; 


class test1 {
  private static Scanner reader;

public static void main(String[] args) {

    reader = new Scanner(System.in); 
    System.out.print("Enter three numbers.");

    int x = reader.nextInt();
    int y = reader.nextInt(); 
    int z = reader.nextInt();

    if (x >= y){
            if (y >= z)
                System.out.print("In Ascending order " + z + " "+ y + " " + x);

            else if  (z >= x)
                System.out.print("In Ascending order " + y + " "+ x + " " + z);

            else   if (x > z)
                System.out.print("In  Ascending order " + y + " " + z + " " + x);
    }

    if (y > x)
    {
            if (z >= y)
                System.out.print("In Ascending order " + x + " " + y + " "+ z);
            else if (z >= x)
            System.out.print("In Ascending order " + y + " " + x + " " + z);
        else if (x > z)
            System.out.print("In Ascending order " + y + " " + z + " " + x);
    }


  }
}
