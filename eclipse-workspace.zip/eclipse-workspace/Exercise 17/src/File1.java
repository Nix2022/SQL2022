import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.io.*;



public class File1 {
	private static String myObj1;
	private static String myObj;
	
//	 public static void printFileSizeNIO(String fileName) {
//
//	        Path path = Paths.get(fileName);
//
//	        try {
//
//	            // size of a file (in bytes)
//	            long bytes = Files.size(path);
//	            System.out.println(String.format("%,d bytes", bytes));
//	            System.out.println(String.format("%,d kilobytes", bytes / 1024));
//
//	        } catch (IOException e) {
//	            e.printStackTrace();
//	        }
//
//	    }
	 

//	public static void copyContent(File myObj, File myObj1)
//            throws Exception
//        {
//            FileInputStream in = new FileInputStream(myObj1);
//            FileOutputStream out = new FileOutputStream(myObj);
//      
//            try {
//      
//                int n;
//      
//                
//                while ((n = in.read()) != -1) {
//                
//                    out.write(n);
//                }
//            }
//            finally {
//                if (in != null) {
//      
//                    
//                    in.close();
//                }
//                
//                if (out != null) {
//                    out.close();
//                }
//            }
//            System.out.println("File Copied");
//            }

  public static void main(String[] args) throws Exception {
    try {
    	
      File myObj = new File("filename.txt");
      if (myObj.createNewFile()) {
        System.out.println("File created: " + myObj.getName());
      } 
    	else {
        System.out.println("File already exists.");
      }
    	 }catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
    
    File f = new File("filename.txt");
    
    // Get the length of the file
    System.out.println("length: "
                       + f.length());
    try {
        File myObj1 = new File("C:\\Users\\nicolas.s\\eclipse-workspace\\Exercise 17\\file2.txt");
        if (myObj1.createNewFile()) {
          System.out.println("File created: " + myObj1.getName());
          
        } else {
          System.out.println("File already exists.");
        }
      } catch (IOException e) {
        System.out.println("An error occurred.");
        e.printStackTrace();
      }
    
    
//    try {
//        File myObj2 = new File("filename1.txt");
//        if (myObj2.createNewFile()) {
//          System.out.println("File created: " + myObj2.getName());
//        } else {
//          System.out.println("File already exists.");
//        }
//      } catch (IOException e) {
//        System.out.println("An error occurred.");
//        e.printStackTrace();
//      }}
    try{
        File myObj = new File("filename.txt");
        Scanner myReader = new Scanner(myObj);
        while (myReader.hasNextLine()) {
          String data = myReader.nextLine();
          System.out.println(data);
        }
        myReader.close();
      } catch (FileNotFoundException e) {
        System.out.println("An error occurred.");
        e.printStackTrace();
      }
//    
    File myObj = new File("filename3.txt"); 
    if (myObj.delete()) { 
      System.out.println("Deleted the file: " + myObj.getName());
    } else {
      System.out.println("Failed to delete the file.");
    }
  
//
//    try {  
//        FileWriter myWriter = new FileWriter("filename1.txt");
//        myWriter.write("Files in Java might be tricky, but it is fun enough!");
//        myWriter.close();
//        System.out.println("Successfully wrote to the file.");
//      } catch (IOException e) {
//        System.out.println("An error occurred.");
//        e.printStackTrace();}
//      } 
//    Scanner sc1 = new Scanner(System.in);
//    
//    // get the source file name
//    System.out.println(
//        "Enter the source filename from where you have to read/copy :");
//    String myObj = sc1.nextLine();
//
//    // source file
//    File x = new File(myObj);
//
//    // get the destination file name
//    System.out.println(
//        "Enter the destination filename where you have to write/paste :");
//    String myObj1 = sc1.nextLine();
//
//    
//    File y = new File(myObj1);
//
//    // method called to copy the
//    // contents from x to y
//    copyContent(x, y);
//    for(int i=0;i<100;i++) {
//        File myObj = new File("filename"+3+".txt");
//        if (myObj.createNewFile()) {
//          System.out.println("File created: " + myObj.getName());
//        } 
//      	else {
//          System.out.println("File already exists.");
//        }
      	}
   
        }
  
  
            
      
         
  
